﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerModel
{
    public float vel;
    public Vector2 pos;
    public float boundX;
}