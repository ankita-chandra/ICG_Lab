﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBarModel
{
    public Vector2 spawnPos;
    public float spawnSpeed;
}